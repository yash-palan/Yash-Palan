#include <iostream>
#include <TF1.h>
#include <TMath.h>
#include <TH1.h>
#include <TH2.h>
#include <TCanvas.h>
#include <TLegend.h>
#include<fstream>
#include "utilities.h"

void file()
{
ifstream a;
a.open("FissionFraction_Burnup_U235.dat");
double U235[49];
double temp;
for (int i=0;i<49;i++)
	{
		a>>temp;
		a>>U235[i];
		cout<<temp<<endl;
		cout<<U235[i]<<endl;
	}
a.close();
cout<<"\n"<<endl;
for (int i=0;i<49;i++)
	{
		cout<<U235[i]<<endl;
	}
}

void File()
{
file();
}
