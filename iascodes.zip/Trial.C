#include <iostream>
#include<TGraphErrors.h>
#include <TF1.h>
#include <TMath.h>
#include <TH1.h>
#include <TCanvas.h>
#include <TMultiGraph.h>


const int nelem=4;
const int nparam=6;
const double en=11.0 , start=2.0;
const int n=90;
double slope = (en-start)/n;
double b[4][6]={
  {3.217    , -3.111    ,  1.395    , -3.690e-01, 4.445e-02, -2.053e-03}, //! U235
  {6.413    , -7.432    ,  3.535    , -8.820e-01, 1.025e-01, -4.550e-03}, //! Pu239
  {4.833e-01,  1.927e-01, -1.283e-01, -6.762e-03, 2.233e-03, -1.536e-04}, //! U238
  {3.251    , -3.204    ,  1.428    , -3.675e-01, 4.254e-02, -1.896e-03}  //! Pu241
};

//! 1 sigma erorrs
double errb[nelem][nparam]={
  {4.02e-02,2.34e-02,4.88e-03,6.08e-04,7.77e-05,6.79e-06},//! U235
  {4.57e-02,2.85e-02,6.44e-03,9.11e-04,1.38e-04,1.29e-05},//! Pu239
  {1.24e-01,5.86e-02,1.11e-02,1.92e-03,2.84e-04,2.86e-05},//! U238
  {4.37e-02,2.60e-02,5.66e-03,7.49e-04,1.02e-04,9.03e-06} //! Pu241
};

double sum1(double *x,int p)
{
  double Sum=0;
  for(int i=0;i<6;i++)
    {
      Sum=Sum+(b[p][i]+errb[p][i])*pow(x[0],i);	
    }
  return(Sum);
}


double sum(double *x,int p,int mode)
{
  double Sum=0;
  if(mode==0)
  	{
		for(int i=0;i<6;i++)
		  {
		    Sum=Sum+b[p][i]*pow(x[0],i);	
		  }
		return(Sum);
	}
  else if(mode==1)
	{
		for(int i=0;i<6;i++)
		    {
		      Sum=Sum+(b[p][i]+errb[p][i])*pow(x[0],i);	
		    }
		return(Sum);
	}
  
  else 
	{
		for(int i=0;i<6;i++)
		    {
		      Sum=Sum+(b[p][i]-errb[p][i])*pow(x[0],i);	
		    }
		return(Sum);
	}

}

double cross_section(double *x)
{
  double result;
  double E_e = x[0]-1.29;
  if(E_e<0.0)
    {
      return(0);	
    }	
  else
    {
      double pe = sqrt(pow(E_e,2)-0.2611);
      result=0.0952*E_e*pe;
      return(result);
    }
}

double flux(double *x,double *p,int mode)
{
  double s;
  double result=0.0;
  for(int i=0;i<4;i++)	
    {
      s=sum(x,i,mode);
      result=result+p[i]*exp(s);	
    }
  return(result);
}

void a_neut(double *result,double *p, int mode)
{
  double *temp=0,x=0.0;
  temp=&x;
  for(int i=0;i<n;i++)
    {
      x=start+slope*(double)i;
      result[i]=flux(temp,p,mode)*cross_section(temp);
    }
}

void plot(double *result,double *p)
{
  double *temp,x=0.0;
  temp=&x;
  for(int i=0;i<n;i++)
    {
      x=start+slope*(double)i;
      result[i]=flux(temp,p,0);
    }
}

void plotc(double *result)
{
  double *temp,x=0.0;
  temp=&x;
  for(int i=0;i<n;i++)
    {
      x=start+slope*(double)i;
      result[i]=cross_section(temp);
    }
}


void fun()
{
  double f1[n]={0},x[n]={0},p[4]={0.58,0.30,0.07,0.05};

  for(int i=0;i<n;i++)
    {
      x[i]=start+slope*(double)i;
    }
  TCanvas *c=new TCanvas("c","Trial",700,700);

  TMultiGraph *mg= new TMultiGraph();
  a_neut(f1,p,0);
  TGraphErrors *g1=new TGraphErrors(n,x,f1);
  g1->SetTitle("Total");
  g1->Draw();
	
  a_neut(f1,p,1);
  TGraphErrors *g6=new TGraphErrors(n,x,f1);
  g6->SetTitle("Total(+ error)");
  g6->SetLineColor(kBlue);  
  
  a_neut(f1,p,2);
  TGraphErrors *g7=new TGraphErrors(n,x,f1);
  g7->SetTitle("Total(- error)");
  g7->SetLineColor(kGreen);
	
  p[0]=0.50;
  p[1]=0.00;
  p[2]=0.0;
  p[3]=0.0;
  plot(f1,p);
  TGraphErrors *g2=new TGraphErrors(n,x,f1);
  g2->SetLineColor(kBlue);
  g2->SetTitle("U-235");

  p[0]=0.0;
  p[1]=0.30;
  plot(f1,p);
  TGraphErrors *g3=new TGraphErrors(n,x,f1);
  g3->SetLineColor(kRed);
  g3->SetTitle("Pu-237");

  p[1]=0.0;
  p[3]=0.05;
  plot(f1,p);
  TGraphErrors *g4=new TGraphErrors(n,x,f1);
  //g4->SetLineColor(kOrange);
  g4->SetTitle("Pu-241");

  p[3]=0.0;
  p[2]=0.07;
  plot(f1,p);
  TGraphErrors *g5=new TGraphErrors(n,x,f1);
  g5->SetLineColor(kGreen+2);
  g5->SetTitle("U-239");

  
  mg->Add(g1);
  //mg->Add(g2);
  //mg->Add(g3);
  //mg->Add(g4);
  //mg->Add(g5);
  mg->Add(g6);
  mg->Add(g7);	
  mg->Draw("a");

  c->BuildLegend();
		
}

void Trial()
{
  fun();
}
