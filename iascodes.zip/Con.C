#include <iostream>
#include <TF1.h>
#include <TMath.h>
#include <TH1.h>
#include <TH2.h>
#include <TCanvas.h>
#include <TLegend.h>
#include "utilities.h"

//------------------------------------------------------------------------------------------------------
//global variable definitions

const double p_mass=938.272,e_mass=0.511,n_mass=939.565;
const double re=1.0;
const double pi=TMath::Pi();
double sigma = 0.1;
double xmin=0.0,xmax=1.0;
//------------------------------------------------------------------------------------------------------

//Gaussian function with mean=0.0 and sigma=sigma
double gaus(double x) 
{
	double result= TMath::Gaus(x,0.0,sigma);
	return result;
}

//The dsigma/dT function for Compton Scattering
double dsigma(double *x,double *p)
{
	double gamma = p[0]/e_mass;
	double s = x[0]/p[0];
	double t = 1.0-s;
	double tmax=p[0] * ((2*gamma)/(1+2*gamma));
	if(x[0]<tmax and x[0]>=0.0)
		{	
			double temp = 2.0 + (s*s)/(gamma*gamma*t*t) + (s/t)*(s- 2.0/gamma);
			double result = ((pi*re*re)/(gamma*gamma*e_mass))*temp;
			return result;
		}
	else
		{
			return(0.0);
		}
}

//Trial function 1
double fun1(double x)
{
	if(0.0<=x and x<=1.0)
		{
			return(1.0);
		}
	else
		{
			return(0.0);
		}
}

//Trial function 2
double fun2(double x)
{
	if(0.0<=x and x<=1.0)
		{
			return(1.0-x);
		}
	else
		{
			return(0.0);
		}
}


//------------------------------------------------------------------------------------------------------

//fun3(x) = f(x)*g(t-x) where t is a parameter, ie p[0]=t
double fun3(double *x, double *p)
{
double result=dsigma(x,&p[1])*gaus(p[0]-x[0]);
return result;
}


//This is required for finding the result of the integration of h(x), ie it performs the actual 
//convolution
double con(double *x,double *p)
{
double ini_ene=0.662;

TF1 *f= new TF1("f",fun3,xmin,xmax,2);
f->SetParameters(x[0],ini_ene);
f->SetNpx(10000);

double result=0.0;
result=f->Integral(xmin,xmax);
return result;
}

//------------------------------------------------------------------------------------------------------

//Used for plotting the final function
void Con()
{
TF1 *f= new TF1("Compton scattering plot",con,xmin,xmax,0);
TCanvas *c= new TCanvas("c","Convolution",854,720);
f->SetNpx(10000);
f->Draw();
}
