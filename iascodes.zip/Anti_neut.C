#include <iostream>
#include <TF1.h>
#include <TMath.h>
#include <TH1.h>
#include <TH2.h>
#include <TCanvas.h>
#include <TLegend.h>
#include<fstream>
#include "Comparision.h"
#include "utilities.h"


double log(double x)
{
  double result=TMath::Log(x);
  return result;
}

const double d=13.0,pi=TMath::Pi(), Pow=100.0, eff= 0.16, np=5.23;
double sigma = 5.91;

double anti_neut_no(double ene,double t) //t in sec, ene in MeVs.
{
  double time = double(t);
  double energy_j=ene*1.6;
  double result= (np*eff*time*Pow*sigma)/(4.0*pi*d*d*energy_j);
  return result;
}
//------------------------------------------------------------------------------------------------------
//Check this once more
const double ene_per_fission[nelem]={201.92,205.52,210.60,213.60}; //{U235,U238,Pu239,Pu241}

double ave_ene(double frac[4])	//Provide fission fraction array[4]
{
  double result=0.0;
  for(int i=0;i<nelem;i++)
    {
      result= result + ene_per_fission[i]*frac[i];
		
    }
  return (result);
}

//------------------------------------------------------------------------------------------------------
//For reading a file

void file()
{
  ifstream a;
  a.open("FissionFraction_Burnup_U235.dat");
  double U235[49];
  double temp;
  for (int i=0;i<49;i++)
    {
      a>>temp;
      a>>U235[i];
      cout<<temp<<endl;
      cout<<U235[i]<<endl;
    }
  a.close();
  cout<<"\n"<<endl;
  for (int i=0;i<49;i++)
    {
      cout<<U235[i]<<endl;
    }
}

//------------------------------------------------------------------------------------------------------

void fun()
{
  ifstream a,b,c,d;
  a.open("FissionFraction_Burnup_U235.dat");
  b.open("FissionFraction_Burnup_U238.dat");
  c.open("FissionFraction_Burnup_Pu239.dat");
  d.open("FissionFraction_Burnup_Pu241.dat");

  double U235[49],U238[49],Pu239[49],Pu241[49];

  double temp;
  for (int i=0;i<49;i++)
    {
      a>>temp;
      a>>U235[i];
      b>>temp;
      b>>U238[i];
      c>>temp;
      c>>Pu239[i];
      d>>temp;
      d>>Pu241[i];
    }
  a.close();
  b.close();
  c.close();
  d.close();
  //The above code is for reading the all the 4 files

  double fiss_frac[nelem],ant_no[49],time[49];;
  double ene[49];
  for(int i=0;i<49;i++)
    {
      // fiss_frac[0]=U235[i];
      // fiss_frac[1]=U238[i];
      // fiss_frac[2]=Pu239[i];
      // fiss_frac[3]=Pu241[i];

      fiss_frac[0]=roundoff(U235[i],3);
      fiss_frac[1]=roundoff(U238[i],3);
      fiss_frac[2]=roundoff(Pu239[i],3);
      fiss_frac[3]=roundoff(Pu241[i],3);
      cout<<i<<endl;
      for(int j=0;j<4;j++){
	cout<<fiss_frac[j]<<endl;
      }
		
      //ene=ave_ene(&fiss_frac[0]);
      //cout<<ene<<endl;
      //time[i]=((double)i+1.0)*10.0;
      //ant_no[i]=anti_neut_no(ene,86400);
      //cout<<ant_no[i]<<endl;			
      //cout<<"\n";

      ene[i]=ave_ene(&fiss_frac[0]);         //ene = Average power of the reactor
      cout<<ene[i]<<endl;
      time[i]=((double)i+1.0)*10.0;
      //double v_ene=Comparision(fiss_frac);    //Anti neutrino energy =v_ene
      //sigma=cross_section(&v_ene)*10;	      //Comparision gives the maxima of the antineutrino spectra
      
      sigma = flux_ave_cs(fiss_frac)*10;
      ant_no[i]=anti_neut_no(ene[i],86400);   //The maxima is then used for flux calculation ( don't 							know how good this approximation is.
      cout<<ant_no[i]<<endl;			
      //cout<<"\n";
						
		
    }
  //The above code is for finding out the number of neutrinos after a certain time

  //TGraphErrors *g1=new TGraphErrors(49,time,ene/*ant_no*/);
  //TCanvas *c1=new TCanvas("c1","energy vs Days passed",700,700);
  //g1->SetMarkerStyle(20);
  //g1->Draw("ap");

  TGraphErrors *g2=new TGraphErrors(49,time,ant_no);
  TCanvas *c2=new TCanvas("c2","Antineutrino no. vs Days passed",700,700);
  g2->SetMarkerStyle(20);
  g2->Draw("ap");
  //The above code is for graphing the results
}
void Anti_neut()
{
  fun();
}

