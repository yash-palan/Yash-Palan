#include <iostream>
#include <TF1.h>
#include <TMath.h>
#include <TH1.h>
#include <TCanvas.h>

double Sum(double x,int p);
double Fun(double *x,double *p);
void flux();

const int nelem =4; //! # of elements
const int nparam=6; //! # of parameters

//! p : is the element U235, Pu239, Pu241, U238
//! b0,b1...b5
double b[nelem][nparam]={{4.367 ,-4.577 , 2.10 ,-0.5294, 0.06186,-0.002777},
			 {4.757 ,-5.392 , 2.63 ,-0.6596, 0.0782 ,-0.003536},
			 {2.99  ,-2.882 ,1.278 ,-0.3343, 0.03905,-0.001754},
			 {4.833 ,1.927  ,-1.283,-6.762 , 2.233  ,-1.536}
};

double Sum(double x,int p)
{
  double sum=0;
  for(int j=0;j<nparam;j++){
    double powterm = pow(x,j);
    sum += b[p][j]*powterm;	
  }
  return sum;
}

double Fun(double *x,double *p)
{
  //! p[i] : a
  double energy=x[0];
  double result=0.0;
  for(int i=0;i<nelem;i++){
    double s=Sum(energy,i);
    result += p[i]*exp(s);	
    //cout << p[i] << "\t" << energy << "\t" << result << endl;
  }

  return result;
}

void flux()
{
  double x[nelem];
  cout<<"Enter the fraction of/n 1. U-235:";
  // cin>>x[0];
  // cout<<"2. Pu-239:";
  // cin>>x[1];
  // cout<<"3. Pu-241:";
  // cin>>x[2];
  // cout<<"3. U-238:";
  // cin>>x[3];


  TF1 *fTotal=new TF1("fTotalFlux",Fun,1.0,11.0,nelem);
  //! Fission fractions (a)
  fTotal->SetParameters(0.58,0.30,0.05,0.07);
  fTotal->FixParameter(0,0.58);
  fTotal->FixParameter(1,0.30);
  fTotal->FixParameter(2,0.05);
  fTotal->FixParameter(3,0.07);
  fTotal->SetLineColor(kBlack);
  fTotal->SetNpx(1000);
  fTotal->GetHistogram()->GetXaxis()->SetRangeUser(2.0,9.0);
  new TCanvas();
  fTotal->Draw();



  TF1 *fU235=new TF1("fU235",Fun,1.0,11.0,nelem);
  //! Fission fractions (a)
  fU235->SetParameters(0.58,0.30,0.05,0.07);
  fU235->FixParameter(0,0.58);
  fU235->FixParameter(1,0.0);
  fU235->FixParameter(2,0.0);
  fU235->FixParameter(3,0.0);
  fU235->SetNpx(1000);
  fU235->SetLineColor(kRed);
  fU235->Draw("lsame");

  TF1 *fPu239=new TF1("fPu239",Fun,1.0,11.0,nelem);
  // //! Fission fractions (a)
  fPu239->SetParameters(0.58,0.30,0.05,0.07);
  fPu239->FixParameter(0,0.0);
  fPu239->FixParameter(1,0.30);
  fPu239->FixParameter(2,0.0);
  fPu239->FixParameter(3,0.0);
  fPu239->SetNpx(1000);
  fPu239->SetLineColor(kGreen+2);
  //new TCanvas();
  fPu239->Draw("lsame");

  TF1 *fPu241=new TF1("fPu241",Fun,1.0,11.0,nelem);
  //! Fission fractions (a)
  fPu241->SetParameters(0.58,0.30,0.05,0.07);
  fPu241->FixParameter(0,0.0);
  fPu241->FixParameter(1,0.0);
  fPu241->FixParameter(2,0.05);
  fPu241->FixParameter(3,0.0);
  fPu241->SetNpx(1000);
  fPu241->SetLineColor(kBlue);
  fPu241->Draw("lsame");

  TF1 *fU238=new TF1("fU238",Fun,1.0,11.0,nelem);
  //! Fission fractions (a)
  fU238->SetParameters(0.58,0.30,0.05,0.07);
  fU238->FixParameter(0,0.0);
  fU238->FixParameter(1,0.0);
  fU238->FixParameter(2,0.0);
  fU238->FixParameter(3,0.07);
  fU238->SetNpx(1000);
  fU238->SetLineColor(kOrange);
  fU238->Draw("lsame");
}
void Sim()
{
  flux();
}
