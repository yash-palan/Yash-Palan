#include <iostream>

#include <TF1.h>
#include <TH1.h>
#include <TCanvas.h>
#include <TLegend.h>

#include "utilities.h"

#define posm    0.510998 // Positron Mass ||=====||
#define neutm 939.565378 // Neutron Mass  || MeV ||
#define protm 938.272046 // Proton Mass   ||=====||

const int nelem=4;
const char *elem[nelem]={"U235","U238","Pu239","Pu241"};
double fiss_frac[nelem]={0.58  , 0.07 , 0.30  , 0.05  }; //! Used by us

//double fiss_frac[nelem]={0.586  , 0.076, 0.288 , 0.05   }; //! Daya Bay
//double fiss_frac[nelem]={0.51   , 0.066, 0.39  , 0.031  }; //! MOX3
//double fiss_frac[nelem]={0.0093 , 0.10 , 0.71  , 0.11   }; //! FBTR

// mean energy of released in fission
double MEPF[nelem] = {201.7,	//! U235
		      205.0,	//! U238
		      210.0,	//! Pu239
		      212.4	//! Pu241
};

const int nparam=6;
const char *bname[nparam]={"b0","b1","b2","b3","b4","b5"};

//! TH A. MULLER et. al PRC 83, 054615 (2011)
double b[nelem][nparam]={
  {3.217    , -3.111    ,  1.395    , -3.690e-01, 4.445e-02, -2.053e-03}, //! U235
  {4.833e-01,  1.927e-01, -1.283e-01, -6.762e-03, 2.233e-03, -1.536e-04}, //! U238
  {6.413    , -7.432    ,  3.535    , -8.820e-01, 1.025e-01, -4.550e-03}, //! Pu239
  {3.251    , -3.204    ,  1.428    , -3.675e-01, 4.254e-02, -1.896e-03}  //! Pu241
};
//! 1 sigma erorrs
double errb[nelem][nparam]={
  {4.02e-02,2.34e-02,4.88e-03,6.08e-04,7.77e-05,6.79e-06},//! U235
  {1.24e-01,5.86e-02,1.11e-02,1.92e-03,2.84e-04,2.86e-05},//! U238
  {4.57e-02,2.85e-02,6.44e-03,9.11e-04,1.38e-04,1.29e-05},//! Pu239
  {4.37e-02,2.60e-02,5.66e-03,7.49e-04,1.02e-04,9.03e-06} //! Pu241
};

//b0+b1*x+b2*x*x+...+b5*x*x*x*x*x

double ApplyCrosSecCorrection(double NeutrinoEn);
double FluxEval(double *x, double *par);
double LSpence(double x);

double FluxEval(double *x, double *par)
{
  double ene = x[0];
  double result=0.0;
  double avene = 0.0;
  for(int i=0; i<nelem; i++){
    avene += par[i]*MEPF[i];
    double sum=0.0;
    if( fabs(par[i]-0.0) < 1.0e-08 )continue;
    for(int j=1; j<=nparam; j++){
      double powterm = pow(ene,j-1);
      sum += b[i][j-1]*powterm;
    }
    result += par[i]*exp(sum);
  }
  double term1 = (sqrt(pow(ene-(neutm-protm),2)-0.510998*0.510998)*109172.85)/(avene);
  double xsec  = (ApplyCrosSecCorrection(ene)*(ene-(neutm-protm)));
  double yield = result/**xsec*0.956*/;

  return yield;
}
double LSpence(double x)
{
  double y=0;
  for(int i=1;i<=20;i++) y+=pow(x,i)/pow(i,2);		// Spence Function
  return -y;
}

double ApplyCrosSecCorrection(double NeutrinoEn)
{
  double M = (neutm+protm)/2.0;
	
  double DELTA = neutm - protm;
  double ysquare = (DELTA*DELTA-posm*posm)/2.0;
  double A = 1.0;
  double B = M+DELTA;
  double C = - M*NeutrinoEn + DELTA*M + ysquare;
		
  double posEn = (-B + sqrt(B*B - 4.0*A*C))/(2.0*A);	// Only positive root makes sense
  double posMom = sqrt(posEn*posEn-posm*posm);
  double BetaEl = posMom/posEn;
		
  double Gee    = 1.26;		// g
  double Eff    = 1.00;		// f
  double Eff2   = 3.70;		// f2
  double alpha  = 1.0/137.0;	// qed alpha
  /*==================================== Recoil Correction ======================================*/
			
  double dRec =  (1.0/(pow(Eff,2)+3*pow(Gee,2)))*((pow(Gee,2)-pow(Eff,2))*
						    DELTA/M+pow((Gee-Eff),2)*(posEn*(posEn+DELTA)+
									      posMom*posMom)/(M*posEn));
			
  /*=============================== Weak Magnetism Correction ===================================*/		
			
  double dWM = (-2.0*Eff2*Gee/(pow(Eff,2)+3*pow(Gee,2)))*(posEn+DELTA+BetaEl*posMom)/M;
	
  /*=================================== Radiative Correction ====================================*/
	
  double EE = NeutrinoEn - DELTA;
  double Beta1 = sqrt(EE*EE-posm*posm)/EE;
	
  double Izero = EE*log(EE/posm)-(EE-posm)*(1.0-log(2.0)+posm/(4.0*EE));
  double Ione = 0.25*((2.0*EE*EE+posm*posm)*log(EE/posm)+(EE-posm)*((EE-posm)*2.0*log(2.0)-3*EE));
  double Iminusone = LSpence(1.0-posm/EE)-(posm/(4.0*EE*EE)*(EE-posm+posm*log(EE/posm)));
	
  double dRad = (alpha/3.142)*(2.0*log(2.0*(EE-posm)/posm)*((1.0/Beta1)*(atanh(Beta1)-1.0))-2.0*
				 log(2.0*(EE+posm)/(posm))+1.5*log(M/posm)+(13.0/8.0)-(2.0/Beta1)*atanh(Beta1)*
				 atanh(Beta1)+(2.0/Beta1)*LSpence(2.0*Beta1/(1.0+Beta1))+Beta1*atanh(Beta1)+
				 (3.0/Beta1)*atanh(Beta1)+1.0/Beta1*(2.0*Iminusone+Ione/(EE*EE)-2.0*Izero/EE));
	
	
  return (1.0 + dRec + dWM + dRad);
}

void Flux()
{
  LoadStyle();

  cout << " neutron mass : "<< neutm << "\t proton mass : " << protm << endl;

  double emin = 1.8;
  double emax = 8.0;
  
  TF1 *fFlux = new TF1("TotalFlux",FluxEval,emin,emax,nelem);
  fFlux->SetParameters(fiss_frac);
  fFlux->SetNpx(10000);

  //fFlux->Draw();

  TH1D *hFlux = (TH1D*)fFlux->GetHistogram();
  MakeHist(hFlux,"Anti-neutrino energy (MeV)","Flux (arb units)");
  hFlux->GetYaxis()->SetTitleOffset(1.08);
  hFlux->GetYaxis()->SetRangeUser(0.0,1.65);
  //hFlux->SetTitle("Total Flux");
  //hFlux->Scale(1./hFlux->GetBinWidth(2));
  TCanvas *c1 = new TCanvas("c1","Reactor AN Flux",854,720);
  c1->SetLeftMargin(0.17);
  c1->SetRightMargin(0.02);
  c1->SetTopMargin(0.02);
  c1->SetBottomMargin(0.20);
  hFlux->SetLineColor(1);  
  hFlux->Draw("hist");
  //return ;

  TF1 *fFluxU235 = new TF1("FluxU235",FluxEval,emin,emax,nelem);
  fFluxU235->SetParameters(fiss_frac[0],0.0,0.0,0.0);
  fFluxU235->SetNpx(10000);
  TH1D *hFluxU235 = (TH1D*)fFluxU235->GetHistogram();
  MakeHist(hFluxU235,"Anti-neutrino energy (MeV)","Flux (arb units)");
  //hFluxU235->SetTitle("{}^{235}U");
  //hFluxU235->Scale(1./hFluxU235->GetBinWidth(2));
  //new TCanvas();
  hFluxU235->SetLineColor(2);  
  hFluxU235->Draw("histsame");
  //return ;
  
  TF1 *fFluxU238 = new TF1("FluxU238",FluxEval,emin,emax,nelem);
  fFluxU238->SetParameters(0.0,fiss_frac[1],0.0,0.0);
  fFluxU238->SetNpx(10000);
  TH1D *hFluxU238 = (TH1D*)fFluxU238->GetHistogram();
  MakeHist(hFluxU238,"Anti-neutrino energy (MeV)","Flux (arb units)");
  //hFluxU238->SetTitle("{}^{238}U");
  //hFluxU238->Scale(1./hFluxU238->GetBinWidth(2));
  // new TCanvas();
  hFluxU238->SetLineColor(4);  
  hFluxU238->Draw("histsame");

  TF1 *fFluxPu239 = new TF1("FluxPu239",FluxEval,emin,emax,nelem);
  fFluxPu239->SetParameters(0.0,0.0,fiss_frac[2],0.0);
  fFluxPu239->SetNpx(10000);
  TH1D *hFluxPu239 = (TH1D*)fFluxPu239->GetHistogram();
  MakeHist(hFluxPu239,"Anti-neutrino energy (MeV)","Flux (arb units)");
  //hFluxPu239->SetTitle("{}^{239}Pu");
  //hFluxPu239->Scale(1./hFluxPu239->GetBinWidth(2));
  //new TCanvas();
  hFluxPu239->SetLineColor(kOrange);  
  hFluxPu239->Draw("histsame");
 
  TF1 *fFluxPu241 = new TF1("FluxPu241",FluxEval,emin,emax,nelem);
  fFluxPu241->SetParameters(0.0,0.0,0.0,fiss_frac[3]);
  fFluxPu241->SetNpx(10000);
  TH1D *hFluxPu241 = (TH1D*)fFluxPu241->GetHistogram();
  MakeHist(hFluxPu241,"Anti-neutrino energy (MeV)","Flux (arb units)");
  //hFluxPu241->SetTitle("{}^{241}Pu");
  //hFluxPu241->Scale(1./hFluxPu241->GetBinWidth(2));
  //new TCanvas();
  hFluxPu241->SetLineColor(8);  
  hFluxPu241->Draw("histsame");


  cout << elem[0] << "\t" << hFluxU235->Integral() << endl;
  cout << elem[1] << "\t" << hFluxU238->Integral() << endl;
  cout << elem[2] << "\t" << hFluxPu239->Integral() << endl;
  cout << elem[3] << "\t" << hFluxPu241->Integral() << endl;
  
  
  //TLegend *leg = c1->BuildLegend(0.4641834,0.5421941,0.8452722,0.8755274,"Reactor #bar{#nu_{e}}","l");
  TLegend *leg =  getLegend(0.463615,0.4510086,0.8450704,0.8760807);
  leg->AddEntry(hFlux,"Total Flux","l");
  leg->AddEntry(hFluxU235,"{}^{235}U","l");
  leg->AddEntry(hFluxU238,"{}^{238}U","l");
  leg->AddEntry(hFluxPu239,"{}^{239}Pu","l");
  leg->AddEntry(hFluxPu241,"{}^{241}Pu","l");
  leg->Draw();
}
