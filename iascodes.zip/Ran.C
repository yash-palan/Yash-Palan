#include <iostream>
#include <TF1.h>
#include <TMath.h>
#include <TH1.h>
#include <TH2.h>
#include <TCanvas.h>
#include <TLegend.h>

#include "utilities.h"

double Sum(double x,int p);
double flux(double *x,double *p);
void fun();
double energy_positron(double x, double theta);

const int nelem =4; //! # of elements
const int nparam=6; //! # of parameters
const double p_mass=938.272,e_mass=0.511,n_mass=939.565;

//-------------------------------------------------------------------------------------------------------
//Code for simulation of the antineutrino spectrum from a given reactor

//! p : is the element U235, Pu239, Pu241, U238
//! b0,b1...b5
double b[nelem][nparam]={
  {3.217    , -3.111    ,  1.395    , -3.690e-01, 4.445e-02, -2.053e-03}, //! U235
  {4.833e-01,  1.927e-01, -1.283e-01, -6.762e-03, 2.233e-03, -1.536e-04}, //! U238
  {6.413    , -7.432    ,  3.535    , -8.820e-01, 1.025e-01, -4.550e-03}, //! Pu239
  {3.251    , -3.204    ,  1.428    , -3.675e-01, 4.254e-02, -1.896e-03}  //! Pu241
};

//! 1 sigma erorrs
double errb[nelem][nparam]={
  {4.02e-02,2.34e-02,4.88e-03,6.08e-04,7.77e-05,6.79e-06},//! U235
  {1.24e-01,5.86e-02,1.11e-02,1.92e-03,2.84e-04,2.86e-05},//! U238
  {4.57e-02,2.85e-02,6.44e-03,9.11e-04,1.38e-04,1.29e-05},//! Pu239
  {4.37e-02,2.60e-02,5.66e-03,7.49e-04,1.02e-04,9.03e-06} //! Pu241
};

//b0+b1*x+b2*x*x+...+b5*x*x*x*x*x

double Sum(double x,int p,int mode)
{
  if(mode==0)
	{
		double sum=0;
		for(int j=0;j<nparam;j++){
			    double powterm = pow(x,j);
			    sum += b[p][j]*powterm;	
			  }
		return sum;
	}
  else if(mode ==1)
	{
		double sum=0;
		for(int j=0;j<nparam;j++){
			    double powterm = pow(x,j);
			    sum += (b[p][j]+errb[p][j])*powterm;	
			  }
		return sum;
	}
  else
	{
		double sum=0;
		for(int j=0;j<nparam;j++){
			    double powterm = pow(x,j);
			    sum += (b[p][j]-errb[p][j])*powterm;	
			  }
		return sum;
	}
}

double cross_section(double *x)			//Used to calculate cross section at a given energy
{
  double result;
  double E_e = x[0]-1.29;			
  if(E_e<0.0)
    {
      return(0);	
    }	
  else
    {
      double pe = sqrt(pow(E_e,2)-0.2611);
      result=0.0952*E_e*pe;
      return(result);
    }
}


double flux(double *x,double *p)		// Used for calculating the flux of antineutrinos from a
{						// given radiation source.
  //! p[i] : a
  double energy=x[0];
  double result=0.0;
  int mode=p[4];
  for(int i=0;i<nelem;i++){
    double s=Sum(energy,i,mode);
    result += p[i]*exp(s);	
    //cout << p[i] << "\t" << energy << "\t" << result << endl;
  }

  return result;
}

double a_neut(double *x,double *p)		//Used for calculating the antineutrino energy given 
{						//cross section and flux.
  double *temp=0,result=0.0;
  temp=&result;
  result=flux(x,p)*cross_section(x);
  return(result);  
}

//-------------------------------------------------------------------------------------------------------
//Code for the simulation of Inverse Beta Decay (IBD)

double energy_positron(double x, double theta)     // Used for calculation of energy of the released 	
{						   // positron.
  double a=0.0,b=0.0,k=0.0;
  a=2.0*x*cos(theta);				   // x = Energy of Antineutrino, theta = angle of 
  b=2*(x+p_mass);				   //scattering.
  k= p_mass*p_mass + e_mass*e_mass - n_mass*n_mass + 2*x*p_mass;
  
  double sub = b*b - a*a;
  double D = k*k - e_mass*e_mass*sub;
  double result = (k*b + a*sqrt(D))/sub;
  return result; 
}

double KE(double ene,double m)		//Used for calculation of KE of particle with energy "ene" and
{					//mass "m"
double p2=ene*ene - m*m;
double result = p2/(2*m);
return result;
}

double beta(double ene, double m)
{
double p=sqrt(ene*ene - m*m);
double result=p/m;
return result;
}

double dist_travel(double v,double ke)
{
double par1 = v*v;
double par2 = 1.0-(v*v);
double par3 = log(15796.0 *par1/par2);
double loss = (1687.5/par1) * (par3 - par1);
double dist = ke/loss;
return dist;
}

//-------------------------------------------------------------------------------------------------------
//Code for plotting the spectrum of the positron energy distribution 
/*
void fun()					 
{						
  double x[nelem],p[4]={0.58 , 0.07 , 0.30  , 0.05  };
  double y=0.0;
  TH1F *h=new TH1F("h","Antineutrino Spectrum",70,2.0,9.0); //Generation of the antineutrino spectrum
  for(int i=0;i<=70;i++)
	{
		double temp=0.0,z=2.0;
		z=2.0+(double)i*0.1; 
		temp=a_neut(&z,p);
		h->SetBinContent(i,temp);
	}
  
  TCanvas *c=new TCanvas("c","c",700,700);
  h->Draw("l");
  h1->Draw("lsame");
  h2->Draw("lsame");
  h3->Draw("lsame");
  h4->Draw("lsame");
  TH2F *g=new TH2F("g","E(ve)-E(e+) histogram",70,2.0,9.0,400,1.2939,1.2943);  
  for(int i=0;i<1000000;i++)
	{
		double temp=0.0,ke=0.0;		
		y=h->GetRandom(); //To get energy considering the shape of the antineutrino spectrum
		
		temp=energy_positron(y,0.0);	//To get the energy of the positron		
						
		g->Fill(y,y-temp);
	}
  g->Draw("colz");		//Draw a line graph of the histogram
}*/


void fun()					 
{						
  double x[nelem],p[4]={0.58 , 0.07 , 0.30  , 0.05  };
  double y=0.0;
  TF1 *f=new TF1("f",a_neut,2.0,9.0,5); //Generation of the antineutrino spectrum
  f->SetParameters(0.58 , 0.07 , 0.30  , 0.05 ,2);
  f->SetNpx(10000);
  
  TH1D *hFlux = (TH1D*)f->GetHistogram();
  hFlux->SetTitle("Total Flux");
  TCanvas *c1 = new TCanvas("c1","Reactor AN Flux",854,720);
  double inte=0.0,bin=0.0;
  inte=hFlux->Integral();
  bin=hFlux->GetBinWidth(2);
  //hFlux->Scale(1./(inte*bin));
  hFlux->SetLineColor(1);  
  hFlux->Draw("hist");

  /*TF1 *f1=new TF1("f1",a_neut,2.0,9.0,5); 
  f1->SetParameters(0.58 , 0.07 , 0.30  , 0.05 ,0);
  f1->SetNpx(10000);
  TH1D *hFlux1 = (TH1D*)f1->GetHistogram();
  hFlux1->SetTitle("Total Flux");
  inte=hFlux1->Integral();
  bin=hFlux1->GetBinWidth(2);
  //hFlux1->Scale(1./(inte*bin));
  hFlux1->SetLineColor(kBlue);  
  hFlux1->Draw("histsame");

  TF1 *f2=new TF1("f",a_neut,2.0,9.0,5); 
  f2->SetParameters(0.58 , 0.07 , 0.30  , 0.05 ,2);
  f2->SetNpx(10000);
  TH1D *hFlux2 = (TH1D*)f2->GetHistogram();
  hFlux2->SetTitle("Total Flux");
  inte=hFlux2->Integral();
  bin=hFlux2->GetBinWidth(2);
  //hFlux2->Scale(1./(inte*bin));
  hFlux2->SetLineColor(kRed);  
  hFlux2->Draw("histsame");*/

}


//---------------------------------------------------------------------------------------------------------

void Ran()
{
  fun();
}

