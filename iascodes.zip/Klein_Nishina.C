#include <iostream>
#include <TF1.h>
#include <TMath.h>
#include <TH1.h>
#include <TH2.h>
#include <TCanvas.h>
#include <TLegend.h>

#include "utilities.h"

const double p_mass=938.272,e_mass=0.511,n_mass=939.565;
const double re=1.0, pi=3.14;


double dsigma(double *x,double *p)
{
	double gamma= p[0]/e_mass;
	double s= x[0]/p[0];
	double t = 1.0-s;
	double tmax=p[0] * ((2*gamma)/(1+2*gamma));
	if(x[0]<tmax)
		{	
			double temp = 2.0 + (s*s)/(gamma*gamma*t*t) + (s/t)*(s- 2.0/gamma);
			double result = ((pi*re*re)/(gamma*gamma*e_mass))*temp;
			return result;
		}
	else
		{
			return(0.0);
		}
}

void fun()
{
double ini_ene=0.6;
cout<<"Enter the value of initial energy of photon:"<<endl;
cin>>ini_ene;

double tmax=0.0,gamma=ini_ene/e_mass;
tmax= ini_ene * ((2*gamma)/(1+2*gamma));

TF1 *f = new TF1("f",dsigma,0.0,2*tmax,1);
TCanvas *c= new TCanvas("c","Klien Nishina",854,720);
f->SetParameter(0,ini_ene);
f->Draw();

cout<<tmax<<endl;
}

void Klein_Nishina()
{
fun();
}
